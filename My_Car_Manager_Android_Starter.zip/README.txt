MY CAR MANAGER - ANDROID STARTER PROJECT

First functional offline starter:
- English interface
- Toyota Corolla Japanese 2016 profile
- PKR currency
- Local SQLite storage; no server or internet needed for normal use
- Add fuel, maintenance, car wash and other expense records
- View saved records and total recorded expenses

BUILD APK USING ONLY YOUR PHONE
1. Sign in to GitHub in your mobile browser and create a repository named MyCarManager.
2. Upload the CONTENTS of this ZIP to the repository root, including the hidden .github folder.
3. Open the repository Actions tab.
4. Select "Build My Car Manager APK" and tap "Run workflow".
5. When the workflow finishes, open that run and download artifact "My-Car-Manager-APK".
6. Extract the artifact ZIP to get app-debug.apk and install it on Android.
Android may ask you to allow installation from your browser or file manager.

IMPORTANT
This is the first starter version, not the final complete feature set. Fuel-average
calculations, reminders, tyre tracking, PDF/Excel export and backup/restore are still
to be added. This source has not been compiled or tested on a physical device in this session.
Keep backups of important records. This debug APK is for initial testing.
