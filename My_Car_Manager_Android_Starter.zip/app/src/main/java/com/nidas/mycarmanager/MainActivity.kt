package com.nidas.mycarmanager

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.*

data class CarRecord(val id: Long, val type: String, val date: String, val title: String, val amount: Double, val details: String)

class RecordsDb(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "mycar.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE records(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT, date TEXT, title TEXT, amount REAL, details TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(type: String, date: String, title: String, amount: Double, details: String) {
        writableDatabase.execSQL("INSERT INTO records(type,date,title,amount,details) VALUES(?,?,?,?,?)",
            arrayOf(type, date, title, amount, details))
    }
    fun all(): List<CarRecord> {
        val out = mutableListOf<CarRecord>()
        readableDatabase.rawQuery("SELECT id,type,date,title,amount,details FROM records ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(CarRecord(c.getLong(0), c.getString(1), c.getString(2), c.getString(3), c.getDouble(4), c.getString(5)))
        }
        return out
    }
    fun total(): Double = readableDatabase.rawQuery("SELECT COALESCE(SUM(amount),0) FROM records", null).use { c -> if(c.moveToFirst()) c.getDouble(0) else 0.0 }
}

class MainActivity : Activity() {
    private lateinit var db: RecordsDb
    private lateinit var root: LinearLayout
    private val navy = Color.rgb(16, 27, 45)
    private val teal = Color.rgb(22, 160, 133)
    private val pale = Color.rgb(242, 246, 249)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = RecordsDb(this)
        showDashboard()
    }

    private fun base(title: String) {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 18, 20, 20)
            setBackgroundColor(pale)
        }
        val header = TextView(this).apply {
            text = title
            textSize = 23f
            setTextColor(Color.WHITE)
            setPadding(18, 22, 18, 22)
            setBackgroundColor(navy)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        root.addView(header)
        setContentView(root)
    }

    private fun text(value: String, size: Float = 16f, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(navy)
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(4, 10, 4, 10)
        }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label; isAllCaps = false
            setTextColor(Color.WHITE); setBackgroundColor(teal)
            setOnClickListener { action() }
        }

    private fun showDashboard() {
        base("MY CAR MANAGER")
        root.addView(text("Toyota Corolla Japanese • 2016", 18f, true))
        root.addView(text("Petrol  |  Currency: PKR", 14f))
        val card = TextView(this).apply {
            text = "TOTAL RECORDED EXPENSES\nPKR ${"%.2f".format(db.total())}"
            textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(12, 28, 12, 28); setBackgroundColor(navy)
        }
        root.addView(card)
        root.addView(text("QUICK ACTIONS", 16f, true))
        root.addView(button("+ Add Fuel Record") { showAdd("Fuel") })
        root.addView(button("+ Add Maintenance") { showAdd("Maintenance") })
        root.addView(button("+ Add Car Wash") { showAdd("Car Wash") })
        root.addView(button("+ Add Other Expense") { showAdd("Expense") })
        root.addView(button("View All Records") { showRecords() })
        root.addView(text("Records are stored locally on this phone. No internet required.", 13f))
    }

    private fun showAdd(type: String) {
        base("ADD $type".uppercase(Locale.getDefault()))
        val date = EditText(this).apply { hint = "Date (YYYY-MM-DD)"; setText(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
        val title = EditText(this).apply { hint = when(type) { "Fuel" -> "Odometer KM / Fuel station"; "Maintenance" -> "Service / Oil / Repair"; "Car Wash" -> "Car wash"; else -> "Expense description" } }
        val amount = EditText(this).apply { hint = "Amount (PKR)"; inputType = 8194 }
        val details = EditText(this).apply { hint = if(type == "Fuel") "Litres, price per litre, odometer, full/partial tank" else "Notes (optional)"; minLines = 2 }
        listOf(date, title, amount, details).forEach { root.addView(it) }
        root.addView(button("SAVE RECORD") {
            val d = date.text.toString().trim()
            val t = title.text.toString().trim()
            val a = amount.text.toString().toDoubleOrNull()
            if (d.isEmpty() || t.isEmpty() || a == null || a < 0) {
                Toast.makeText(this, "Enter a valid date, description and amount.", Toast.LENGTH_LONG).show()
            } else {
                db.add(type, d, t, a, details.text.toString())
                Toast.makeText(this, "Record saved on this phone.", Toast.LENGTH_SHORT).show()
                showDashboard()
            }
        })
        root.addView(button("CANCEL") { showDashboard() })
    }

    private fun showRecords() {
        base("ALL RECORDS")
        val records = db.all()
        if (records.isEmpty()) root.addView(text("No records yet. Add your first record from the dashboard."))
        records.forEach { r ->
            val line = "${r.type} • ${r.date}\n${r.title}\nPKR ${"%.2f".format(r.amount)}" +
                if (r.details.isNotBlank()) "\n${r.details}" else ""
            val item = TextView(this).apply {
                text = line; textSize = 15f; setTextColor(navy)
                setPadding(14, 14, 14, 14); setBackgroundColor(Color.WHITE)
            }
            val params = LinearLayout.LayoutParams(-1, -2)
            params.setMargins(0, 6, 0, 6)
            root.addView(item, params)
        }
        root.addView(button("BACK TO DASHBOARD") { showDashboard() })
    }
}
